-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Máy chủ: 127.0.0.1
-- Thời gian đã tạo: Th10 17, 2021 lúc 06:32 AM
-- Phiên bản máy phục vụ: 10.4.19-MariaDB
-- Phiên bản PHP: 8.0.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Cơ sở dữ liệu: `du_an_mau`
--

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `binh_luan`
--

CREATE TABLE `binh_luan` (
  `ma_bl` int(11) NOT NULL,
  `noi_dung` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ma_sp` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ma_kh` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ngay_bl` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `binh_luan`
--

INSERT INTO `binh_luan` (`ma_bl`, `noi_dung`, `ma_sp`, `ma_kh`, `ngay_bl`) VALUES
(6, 'ád', '7', 'admin', '2021-09-01'),
(7, 'có trả góp ko shop', '26', 'huanrose', '2021-09-01'),
(8, 'good job', '26', 'admin', '2021-10-01'),
(9, 'đẹp\r\n', '12', 'admin', '2021-10-07'),
(10, 'đẹp đấy', '40', 'khabanh113', '2021-10-14'),
(11, 'bảnh muốn mua', '40', 'khabanh113', '2021-10-14');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `hang_hoa`
--

CREATE TABLE `hang_hoa` (
  `id` int(11) NOT NULL,
  `ma_sp` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `ten_sp` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `so_luong` int(11) NOT NULL,
  `gia` int(11) NOT NULL,
  `don_vi` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mo_ta` varchar(2000) COLLATE utf8_unicode_ci NOT NULL,
  `img` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten_loai` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `dac_biet` int(2) NOT NULL DEFAULT 0 COMMENT 'Đặc biệt'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `hang_hoa`
--

INSERT INTO `hang_hoa` (`id`, `ma_sp`, `ten_sp`, `so_luong`, `gia`, `don_vi`, `mo_ta`, `img`, `ten_loai`, `dac_biet`) VALUES
(1, '13900AA05', 'ĐỒNG HỒ LOUIS ERARD NAM PIN DÂY DA', 1, 28983898, 'chiếc', 'Đây là dòng sản phẩm tuyệt vời cho những người đang tìm kiếm chiếc đồng hồ được thiết kế riêng mang đầy đủ sự “chất” Vintage cho đến hiện nay, đó là “chất cổ điển” và chỉ là “cổ điển” tinh khiết.\r\n\r\n', 'assets/img/donghonam5.png', 'Đồng hồ nam', 1),
(5, ' T30', 'ĐỒNG HỒ HUBLOT NAM DÂY DA', 20, 14000900, 'chiếc', 'Đồng hồ Seiko SGEG99P1 dành cho nam, mặt đồng hồ màu đen, chữ số La Mã lớn màu trắng, vỏ thép không gỉ, dây da màu đen, mặt kính Sapphire chịu lực chống trầy, 1 ô lịch hiển thị ngày.\r\n\r\n', 'assets/img/donghonam7.png', 'Đồng hồ nam', 0),
(6, 'VIP099', 'ĐỒNG HỒ ĐEO VÀO AUTO ĐẸP TRAI NHA', 123, 2147483647, 'chiếc', 'Đồng hồ Orient FSTAA002W0 có vỏ kim loại phủ màu vàng sang trọng, kim chỉ và vạch số thanh mãnh nổi bật trên nền số, ô lịch ngày vị trí 3h tinh tế, dây đeo bằng chất liệu da cao cấp màu nâu đem lại phong cách lịch lãm, sang trọng cho phái mạnh\r\n\r\n', 'assets/img/donghonam8.png', 'Đồng hồ nam', 0),
(7, ' K98', 'ĐỒNG HỒ GIÁ RẺ KHÔNG THÍCH THÌ MUA', 34, 2147483647, 'chiếc', 'Mẫu đồng hồ Olym Pianus OP99141-71AGSK vẻ ngoài tinh tế sang trọng ấn tượng với kiểu thiết kế độc đáo đến từ ô chân kính phô diễn ra 1 phần trải nghiệm hoạt động của bộ máy cơ đầy nam tính.\r\n\r\n', 'assets/img/donghonam6.png', 'Đồng hồ nam', 0),
(8, ' 13900AA05.BDC102', 'ĐỒNG HỒ LOUIS ERARD 13900AA05.BDC102 NAM PIN DÂY DA', 5, 18195300, 'chiếc', 'Đồng hồ nam CASIO GA-110GB-1AVDF có thiết kế mới sử dụng kim loại màu vàng làm vạch số và kim nổi bật, sang trọng hơn so với thiết kế cũ nên mẫu GA-110GB-1AVDF rất được lòng giới trẻ hiện nay.\r\n\r\n', 'assets/img/donghonam1.png', 'Đồng hồ nam', 0),
(9, ' T063.907.11.058.00', 'ĐỒNG HỒ TISSOT T063.907.11.058.00 NAM TỰ ĐỘNG DÂY INOX', 0, 21940000, 'chiếc', 'Đồng hồ nam CASIO MTP-1374L-1AVDF thay cho thiết kế cửa sổ lich cổ điển là thiết kế mới lịch ngày và thứ đều sử dụng đồng hồ kim mang tính hiện đại, trẻ trung. Nổi bật trên nền mặt số đen là thiết kế phá cách kim giây đỏ làm điểm nhấn nổi bật. Dây đeo bằng da tạo vân cá sấu nổi bật với hai đường chỉ may trắng tinh xảo.\r\n\r\n', 'assets/img/donghonam3.png', 'Đồng hồ nam', 0),
(10, 'T41.1.183.34', 'ĐỒNG HỒ TISSOT NỮ TỰ ĐỘNG DÂY INOX', 20, 17640000, 'chiếc', 'Mẫu Tissot T41.1.183.34 vẻ ngoài giản dị của chiếc đồng hồ 3 kim nhưng lại khoác lên sự trang nhã với nền mặt số được phối tông màu trắng trước bề mặt kính Sapphire kết hợp cùng tổng thể chiếc đồng hồ kim loại màu bạc đầy sang trọng.\r\n\r\n', 'assets/img/dong-ho-tissot-t41.1.183.34.png', 'Đồng hồ nữ', 0),
(12, 'C4433/3', 'ĐỒNG HỒ CANDINO C4433/3 NỮ PIN DÂY INOX', 100, 3996000, 'chiếc', 'Đồng hồ dây da thời trang nữ Candino C4433/3, với mặt đồng hồ sang trọng nền trắng có ánh xà cừ có đính hạt pha lê viền xung quang, kính Sapphire, chữ số lớn dễ đọc, 3 kim chỉ màu bạc.\r\n\r\n', 'assets/img/dong-ho-candino-c4433_3-nu-pin-day-inox.png', 'Đồng hồ nữ', 0),
(13, 'GA-100DE-2ADR', 'ĐỒNG HỒ CASIO GA-100DE-2ADR NỮ PIN DÂY NHỰA', 3, 4393000, 'chiếc', 'Mẫu G-Shock GA-100DE-2ADR với vẻ ngoài cá tính thích hợp cho những bạn trẻ năng động, phù hợp cho những chuyến đi phượt ấn tượng với khả năng chịu nước lên đến 20ATM, với đồng hồ điện tử hiện thị đa chức năng tiện ích.\r\n\r\n', 'assets/img/dong-ho-casio-ga-100de-2adr-nu-pin-day-nhua.png', 'Đồng hồ nữ', 0),
(14, 'LA670WL', 'ĐỒNG HỒ CASIO LA670WL-1BDF NỮ PIN DÂY DA', 40, 766000, 'chiếc', 'Mẫu đồng hồ Casio LA670WL-1BDF  với thiết kế bộ máy nhỏ gọn tạo nên vẻ ngoài thanh mảnh nữ tính, vỏ máy tông màu vàng phối cùng mẫu dây đeo kim loại đen tăng thêm vẻ đẹp thời trang.\r\n\r\n', 'assets/img/dong-ho-casio-la670.png', 'Đồng hồ nữ', 0),
(15, 'EX1410-88A', 'ĐỒNG HỒ CITIZEN EX1410-88A NỮ ECO-DRIVE DÂY INOX', 5, 8721877, 'chiếc', 'Đồng hồ Citizen EX1410-88A có mặt số hình chữ nhật bầu tinh tế, kim chỉ và vạch số thanh mãnh nổi bật trên nền số màu trắng trang nhã, phần quai được đính pha lê Swarovski sang trọng mang đến vẻ thanh lịch, duyên dáng dành cho phái nữ.\r\n\r\n', 'assets/img/EX1410-88A-600x600.png', 'Đồng hồ nữ', 0),
(16, 'DW00500001', 'ĐỒNG HỒ DANIEL WELLINGTON NỮ PIN DÂY INOX', 50, 15000999, 'chiếc', 'Mẫu đồng hồ nữ Daniel Wellington DW00500001 với nét đặc trưng giản dị đến từ thương hiệu Daniel Wellington với thiết kế bộ máy nhỏ gọn thanh mảnh kết hợp cùng mẫu dây đeo chất liệu vải mang phong cách trẻ trung.\r\n\r\n', 'assets/img/dong-ho-daniel-wellington-dw00500001-nu.png', 'Đồng hồ nữ', 0),
(17, 'OG385', 'ĐỒNG HỒ NỮ PIN DÂY INOX', 10, 9384000, 'chiếc', 'Vẻ ngoài trẻ trung với phần mặt số được phối tông nền trắng có họa tiết thời trang nữ tính với vỏ máy dày dặn chứa đựng một trải nghiệm nữ tính từ bộ may cơ là yếu tố tạo nên mẫu đồng hồ nữ Ogival.\r\n\r\n', 'assets/img/dong-ho-ogival-og385-032lw.png', 'Đồng hồ nữ', 0),
(26, 'SGEG99P1', 'ĐỒNG HỒ SEIKO SGEG99P1 NAM PIN DÂY DA', 80, 3879878, 'chiếc', 'Đồng hồ Seiko SGEG99P1 dành cho nam, mặt đồng hồ màu đen, chữ số La Mã lớn màu trắng, vỏ thép không gỉ, dây da màu đen, mặt kính Sapphire chịu lực chống trầy, 1 ô lịch hiển thị ngày.\r\n\r\n', 'assets/img/donghonam4.png', 'Đồng hồ nam', 1),
(27, 'AU1080-20A', 'ĐỒNG HỒ CITIZEN AU1080-20A NAM ECO-DRIVE DÂY VẢI', 9, 8782749, 'chiếc', 'Đồng hồ nam Citizen AU1080-20A nổi bật Pin sử dụng công nghệ hiện đại Eco-Drive (Năng Lượng Ánh Sáng), với thiết kế theo phong cách thời trang với dây đeo chất liệu bằng vải tông màu kem trẻ trung.\r\n\r\n', 'assets/img/donghonam2.png', 'Đồng hồ nam', 0),
(35, ' AC8C26', 'ĐỒNG HỒ ĐÔI ALEXANDRE CHRISTIE – AC8C26-1MK TRẮNG PIN DÂY INOX', 20, 8237879, 'cặp', 'ALEXANDRE CHRISTIE là thương hiệu đồng hồ chính hãng nổi tiếng của Nhật Bản với những thiết kế cầu kỳ và vô cùng tinh tế. Ngay từ khi ra đời mẫu đồng hồ đeo tay này đã nhanh chóng được mọi người yêu thích vì chất lượng tốt động cơ bền bỉ vô cùng sang trọng.\r\n\r\n', 'assets/img/donghodoi1.png', 'Đồng hồ đôi', 0),
(36, 'MTP', 'ĐỒNG HỒ ĐÔI CASIO MTP-E312D-7BVDF – LTP-E312D-4BVDF PIN DÂY INOX', 5, 13145354, 'cặp', 'Đồng hồ đôi Casio với phong cách trẻ trung, vạch số được thiết kế mỏng tinh tế kèm theo 3 ô phụ với 3 chức năng tiện ích, vỏ máy cùng với dây đeo kim loại đem lại vẻ chắc chắn bền vững cho cặp đôi.\r\n\r\n', 'assets/img/donghodoi2.png', 'Đồng hồ đôi', 1),
(39, 'PHUK1', 'HIRSCH MARINER', 22, 560000, 'chiếc', 'Mẫu dây da Hirsch MARINER mẫu dây không bao giờ lỗi mốt, bắt mắt với thiết kế thể thao nhưng vẫn mềm mại.\r\n\r\n', 'assets/img/phu_kien1.png', 'Phụ kiện', 0),
(40, 'ES1L276M1095', 'ĐỒNG HỒ NỮ ESPRIT ES1L276M1095', 20, 4500000, 'chiếc', '- Mẫu đồng hồ nữ đến từ thương hiệu Esprit nổi tiếng của Mỹ, nổi bật với vẻ đẹp sang trọng, quý phái\r\n\r\n- Chiếc đồng hồ Esprit này có đường kính mặt 32 mm, độ rộng dây 16 mm\r\n\r\n- Chất liệu thép không gỉ được sử dụng cho khung viền và dây đeo của đồng hồ mang đến vẻ ngoài sáng bóng cùng sự bền bỉ thách thức thời gian\r\n\r\n- Thoải mái đeo đồng hồ khi tắm, đi mưa hay rửa tay nhờ khả năng chống nước 5 ATM, không nên mang khi bơi, lặn', 'assets/img/donghonu_esprit.png', 'Đồng hồ nữ', 1);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `khach_hang`
--

CREATE TABLE `khach_hang` (
  `id` int(11) NOT NULL,
  `ma_kh` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ten` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `sdt` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `dia_chi` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `gioi_tinh` int(11) NOT NULL DEFAULT 0,
  `email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `mat_khau` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `vai_tro` int(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `khach_hang`
--

INSERT INTO `khach_hang` (`id`, `ma_kh`, `ten`, `sdt`, `dia_chi`, `gioi_tinh`, `email`, `mat_khau`, `vai_tro`) VALUES
(1, 'admin', ' Quang Linh', '0999999999', 'Việt Nam', 1, 'linhdqph14703@fpt.edu.vn', 'admin', 1),
(6, 'vip', 'Loki', '09666666', 'Cao Bằng', 1, 'loki666@hell.com', 'anhemoi', 0),
(9, 'khabanh113', 'Ngô Bá Khá', '0113112114', 'Nhà tù', 1, 'nogamenolife.why@gmail.com', '123123', 0),
(10, 'huanrose', 'Bùi Xuân Huấn', '0987654321', 'Trại cai nghiện ma túy cơ sở 3', 1, 'huanrose113@gmail.com', 'huandeptrai', 0),
(11, 'mcr17', 'Messi Ronaldo', '01238983297', 'Football Central', 1, 'messironaldo@gmail.com', '123456789', 0),
(12, 'kamen', 'Rider', '0626382778', 'Japan', 1, 'kamenrider@gmail.com', '123123123123', 0);

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `loai_hang`
--

CREATE TABLE `loai_hang` (
  `ma_loai` int(11) NOT NULL,
  `ten_loai` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `loai_hang`
--

INSERT INTO `loai_hang` (`ma_loai`, `ten_loai`) VALUES
(1, 'Đồng hồ nam'),
(2, 'Đồng hồ nữ'),
(3, 'Đồng hồ đôi'),
(4, 'Phụ kiện');

-- --------------------------------------------------------

--
-- Cấu trúc bảng cho bảng `slider`
--

CREATE TABLE `slider` (
  `id` int(11) NOT NULL,
  `image_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `slide_src` varchar(255) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Đang đổ dữ liệu cho bảng `slider`
--

INSERT INTO `slider` (`id`, `image_name`, `slide_src`) VALUES
(1, 'slide1.jpg', 'assets/img/slide1.jpg'),
(2, 'slide2.jpg', 'assets/img/slide2.jpg'),
(3, 'slide3.jpg', 'assets/img/slide3.jpg');

--
-- Chỉ mục cho các bảng đã đổ
--

--
-- Chỉ mục cho bảng `binh_luan`
--
ALTER TABLE `binh_luan`
  ADD PRIMARY KEY (`ma_bl`);

--
-- Chỉ mục cho bảng `hang_hoa`
--
ALTER TABLE `hang_hoa`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `khach_hang`
--
ALTER TABLE `khach_hang`
  ADD PRIMARY KEY (`id`);

--
-- Chỉ mục cho bảng `loai_hang`
--
ALTER TABLE `loai_hang`
  ADD PRIMARY KEY (`ma_loai`);

--
-- Chỉ mục cho bảng `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT cho các bảng đã đổ
--

--
-- AUTO_INCREMENT cho bảng `binh_luan`
--
ALTER TABLE `binh_luan`
  MODIFY `ma_bl` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT cho bảng `hang_hoa`
--
ALTER TABLE `hang_hoa`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=41;

--
-- AUTO_INCREMENT cho bảng `khach_hang`
--
ALTER TABLE `khach_hang`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT cho bảng `loai_hang`
--
ALTER TABLE `loai_hang`
  MODIFY `ma_loai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT cho bảng `slider`
--
ALTER TABLE `slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
